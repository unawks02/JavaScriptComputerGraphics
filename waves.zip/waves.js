//a little messed-up skymap :(
//ignore the watermarks please

function start() {

    // Get canvas, WebGL context, twgl.m4
    var canvas = document.getElementById("mycanvas");
    var gl = canvas.getContext("webgl");

    // Sliders at center
    var slider1 = document.getElementById('slider1');
    slider1.value = 0;
	var slider2 = document.getElementById('slider2');
    slider2.value = 0;

	var shaderProgram = gl.createProgram();
	var shaderProgram2 = gl.createProgram();
	var shaderProgram3 = gl.createProgram();
	
		// Read shader source
    var vertexSource = document.getElementById("vertexShader").text;
    var fragmentSource = document.getElementById("fragmentShader").text;

    // Compile vertex shader
    var vertexShader = gl.createShader(gl.VERTEX_SHADER);
    gl.shaderSource(vertexShader,vertexSource);
    gl.compileShader(vertexShader);
    if (!gl.getShaderParameter(vertexShader, gl.COMPILE_STATUS)) {
      alert(gl.getShaderInfoLog(vertexShader)); return null; }
    
    // Compile fragment shader
    var fragmentShader = gl.createShader(gl.FRAGMENT_SHADER);
    gl.shaderSource(fragmentShader,fragmentSource);
    gl.compileShader(fragmentShader);
    if (!gl.getShaderParameter(fragmentShader, gl.COMPILE_STATUS)) {
      alert(gl.getShaderInfoLog(fragmentShader)); return null; }
	  
    
    // Attach the shaders and link
    gl.attachShader(shaderProgram, vertexShader);
    gl.attachShader(shaderProgram, fragmentShader);
    gl.linkProgram(shaderProgram);
    if (!gl.getProgramParameter(shaderProgram, gl.LINK_STATUS)) {
      alert("Could not initialize shaders"); }
    gl.useProgram(shaderProgram);	    
    
    // with the vertex shader, we need to pass it positions
    // as an attribute - so set up that communication
    shaderProgram.PositionAttribute = gl.getAttribLocation(shaderProgram, "vPosition");
    gl.enableVertexAttribArray(shaderProgram.PositionAttribute);
    
    shaderProgram.NormalAttribute = gl.getAttribLocation(shaderProgram, "vNormal");
    gl.enableVertexAttribArray(shaderProgram.NormalAttribute);
    
    shaderProgram.ColorAttribute = gl.getAttribLocation(shaderProgram, "vColor");
    gl.enableVertexAttribArray(shaderProgram.ColorAttribute);
    
	shaderProgram.texcoordAttribute = gl.getAttribLocation(shaderProgram, "vTexCoord");
    gl.enableVertexAttribArray(shaderProgram2.texcoordAttribute);
   
    // this gives us access to the matrix uniform
    shaderProgram.MVmatrix = gl.getUniformLocation(shaderProgram,"uMV");
    shaderProgram.MVNormalmatrix = gl.getUniformLocation(shaderProgram,"uMVn");
    shaderProgram.MVPmatrix = gl.getUniformLocation(shaderProgram,"uMVP");
	
	// Attach samplers to texture units
    shaderProgram.texSampler1 = gl.getUniformLocation(shaderProgram, "texSampler1");
    gl.uniform1i(shaderProgram.texSampler1, 0);
	
	   // Read shader source x2
    var vertexSource = document.getElementById("vertexShader2").text;
    var fragmentSource = document.getElementById("fragmentShader2").text;

    // Compile vertex shader
    var vertexShader2 = gl.createShader(gl.VERTEX_SHADER);
    gl.shaderSource(vertexShader2,vertexSource);
    gl.compileShader(vertexShader2);
    if (!gl.getShaderParameter(vertexShader2, gl.COMPILE_STATUS)) {
      alert(gl.getShaderInfoLog(vertexShader2)); return null; }
    
    // Compile fragment shader
    var fragmentShader2 = gl.createShader(gl.FRAGMENT_SHADER);
    gl.shaderSource(fragmentShader2,fragmentSource);
    gl.compileShader(fragmentShader2);
    if (!gl.getShaderParameter(fragmentShader2, gl.COMPILE_STATUS)) {
      alert(gl.getShaderInfoLog(fragmentShader2)); return null; }
	  
    
    // Attach the shaders and link
    gl.attachShader(shaderProgram2, vertexShader2);
    gl.attachShader(shaderProgram2, fragmentShader2);
    gl.linkProgram(shaderProgram2);
    if (!gl.getProgramParameter(shaderProgram2, gl.LINK_STATUS)) {
      alert("Could not initialize shaders"); }
    gl.useProgram(shaderProgram2);	    
    
    // with the vertex shader, we need to pass it positions
    // as an attribute - so set up that communication
    shaderProgram2.PositionAttribute = gl.getAttribLocation(shaderProgram2, "vPosition");
    gl.enableVertexAttribArray(shaderProgram2.PositionAttribute);
    
    shaderProgram2.NormalAttribute = gl.getAttribLocation(shaderProgram2, "vNormal");
    gl.enableVertexAttribArray(shaderProgram2.NormalAttribute);
    
    shaderProgram2.ColorAttribute = gl.getAttribLocation(shaderProgram2, "vColor");
    gl.enableVertexAttribArray(shaderProgram2.ColorAttribute);
    
    shaderProgram2.texcoordAttribute = gl.getAttribLocation(shaderProgram2, "vTexCoord");
    gl.enableVertexAttribArray(shaderProgram2.texcoordAttribute);
   
    // this gives us access to the matrix uniform
    shaderProgram2.MVmatrix = gl.getUniformLocation(shaderProgram2,"uMV");
    shaderProgram2.MVNormalmatrix = gl.getUniformLocation(shaderProgram2,"uMVn");
    shaderProgram2.MVPmatrix = gl.getUniformLocation(shaderProgram2,"uMVP");

	 // Attach samplers to texture units
    shaderProgram2.texSampler2 = gl.getUniformLocation(shaderProgram2, "texSampler2");
    gl.uniform1i(shaderProgram2.texSampler2, 0);
	
	   // Read shader source x3
    var vertexSource = document.getElementById("vertexShader3").text;
    var fragmentSource = document.getElementById("fragmentShader3").text;

    // Compile vertex shader
    var vertexShader3 = gl.createShader(gl.VERTEX_SHADER);
    gl.shaderSource(vertexShader3,vertexSource);
    gl.compileShader(vertexShader3);
    if (!gl.getShaderParameter(vertexShader3, gl.COMPILE_STATUS)) {
      alert(gl.getShaderInfoLog(vertexShader3)); return null; }
    
    // Compile fragment shader
    var fragmentShader3 = gl.createShader(gl.FRAGMENT_SHADER);
    gl.shaderSource(fragmentShader3,fragmentSource);
    gl.compileShader(fragmentShader3);
    if (!gl.getShaderParameter(fragmentShader3, gl.COMPILE_STATUS)) {
      alert(gl.getShaderInfoLog(fragmentShader3)); return null; }
	  
    
    // Attach the shaders and link
    gl.attachShader(shaderProgram3, vertexShader3);
    gl.attachShader(shaderProgram3, fragmentShader3);
    gl.linkProgram(shaderProgram3);
    if (!gl.getProgramParameter(shaderProgram3, gl.LINK_STATUS)) {
      alert("Could not initialize shaders"); }
    gl.useProgram(shaderProgram3);	    
    
    // with the vertex shader, we need to pass it positions
    // as an attribute - so set up that communication
    shaderProgram3.PositionAttribute = gl.getAttribLocation(shaderProgram3, "vPosition");
    gl.enableVertexAttribArray(shaderProgram3.PositionAttribute);
    
    shaderProgram3.NormalAttribute = gl.getAttribLocation(shaderProgram3, "vNormal");
    gl.enableVertexAttribArray(shaderProgram3.NormalAttribute);
    
    shaderProgram3.ColorAttribute = gl.getAttribLocation(shaderProgram3, "vColor");
    gl.enableVertexAttribArray(shaderProgram3.ColorAttribute);
    
    shaderProgram3.texcoordAttribute = gl.getAttribLocation(shaderProgram3, "vTexCoord");
    gl.enableVertexAttribArray(shaderProgram3.texcoordAttribute);
   
    // this gives us access to the matrix uniform
    shaderProgram3.MVmatrix = gl.getUniformLocation(shaderProgram3,"uMV");
    shaderProgram3.MVNormalmatrix = gl.getUniformLocation(shaderProgram3,"uMVn");
    shaderProgram3.MVPmatrix = gl.getUniformLocation(shaderProgram3,"uMVP");

	 // Attach samplers to texture units
    shaderProgram3.texSampler3 = gl.getUniformLocation(shaderProgram3, "texSampler3");
    gl.uniform1i(shaderProgram3.texSampler3, 0);
	
var vertexPos = new Float32Array(
        [  1, 1, 1,  -1, 1, 1,  -1,-1, 1,   1,-1, 1,
           1, 1, 1,   1,-1, 1,   1,-1,-1,   1, 1,-1,
           1, 1, 1,   1, 1,-1,  -1, 1,-1,  -1, 1, 1,
          -1, 1, 1,  -1, 1,-1,  -1,-1,-1,  -1,-1, 1,
          -1,-1,-1,   1,-1,-1,   1,-1, 1,  -1,-1, 1,
           1,-1,-1,  -1,-1,-1,  -1, 1,-1,   1, 1,-1 ]);

    // vertex normals
    var vertexNormals = new Float32Array(
        [  0, 0, 1,   0, 0, 1,   0, 0, 1,   0, 0, 1, 
           1, 0, 0,   1, 0, 0,   1, 0, 0,   1, 0, 0, 
           0, 1, 0,   0, 1, 0,   0, 1, 0,   0, 1, 0, 
          -1, 0, 0,  -1, 0, 0,  -1, 0, 0,  -1, 0, 0, 
           0,-1, 0,   0,-1, 0,   0,-1, 0,   0,-1, 0, 
           0, 0,-1,   0, 0,-1,   0, 0,-1,   0, 0,-1  ]);

    // vertex colors
    var vertexColors = new Float32Array(
        [  0, 0, 1,   0, 0, 1,   0, 0, 1,   0, 0, 1,
           1, 0, 0,   1, 0, 0,   1, 0, 0,   1, 0, 0,
           0, 1, 0,   0, 1, 0,   0, 1, 0,   0, 1, 0,
           1, 1, 0,   1, 1, 0,   1, 1, 0,   1, 1, 0,
           1, 0, 1,   1, 0, 1,   1, 0, 1,   1, 0, 1,
           0, 1, 1,   0, 1, 1,   0, 1, 1,   0, 1, 1 ]);
		   
		   // vertex texture coordinates
    var vertexTextureCoords = new Float32Array(
        [  0, 0,   1, 0,   1, 1,   0, 1,
           1, 0,   1, 1,   0, 1,   0, 0,
           0, 1,   0, 0,   1, 0,   1, 1,
           0, 0,   1, 0,   1, 1,   0, 1,
           1, 1,   0, 1,   0, 0,   1, 0,
           1, 1,   0, 1,   0, 0,   1, 0 ]);
		   
	var vertexTextureCoords2 = new Float32Array(
        [
		   0.67, 0.33,   0.99, 0.33,   0.99, 0.66,   0.67, 0.66, //front
		   0.33, 0,   0.33, 0.33,   0, 0.33,    0,0, //right
           0.34, 0,   0.66, 0,   0.66, 0.33,   0.34, 0.33, //top
           0,0.33,   0.33, 0.33,   0.33, 0.66,   0, 0.66, //left
           0.34, 0.34,   0.66, 0.34,   0.66, 0.66,   0.34, 0.66, //bottom
		   0.99, 0.33,   0.67, 0.33,   0.67, 0,   0.99, 0]); //back
		  
    // element index array
    var triangleIndices = new Uint16Array(
        [  0, 1, 2,   0, 2, 3,    // front
           4, 5, 6,   4, 6, 7,    // right
           8, 9,10,   8,10,11,    // top
          12,13,14,  12,14,15,    // left
          16,17,18,  16,18,19,    // bottom
	      20,21,22,  20,22,23 ]); // back
		  
	var vertexPos3 = new Float32Array( //for triangular prism
        [  -1, 0, -1,   0, 1, 0,   0, 0, 1,   //left
		   1, 0, -1,    0, 1, 0,   0, 0, 1,   //right
		   -1, 0, -1,   0, 1, 0,   1, 0, -1,  //back
		   -1, 0, -1,   0, 0, 1,   1, 0, -1]);//bottom
		   
	var vertexNormals3 = new Float32Array(
        [  -1, 0, 1,    -1, 0, 1,   -1, 0, 1,   //left
		    1, 0, 1,     1, 0, 1,    1, 0, 1,   //right
		    0, 0, -1,    0, 0, -1,   0, 0, -1,  //back
		   0, -1, 0,     0, -1, 0,   0, -1, 0]);//bottom

    // vertex colors
    var vertexColors3 = new Float32Array(
        [  1, 0, 0,    1, 0, 0,   1, 0, 0,   //left
		   1, 0, 0,    1, 0, 0,   1, 0, 0,   //right
		   1, 0, 0,    1, 0, 0,   1, 0, 0,   //back
		   1, 0, 0,    1, 0, 0,   1, 0, 0]); //bottom
		   
	var vertexTextureCoords3 = new Float32Array(
        [  0, 0,   1, 0,   1, 1,   //left
           0, 0,   1, 0,   1, 1,   //right
           0, 0,   1, 0,   0, 1,   //back
           0, 0,   1, 0,   1, 1]); //bottom
		   
	var triangleIndices3 = new Uint16Array(
        [ 0, 1, 2,     // right
          3, 4, 5,     // left
          6, 7, 8,     // bottom
	      9, 10, 11]); // back

    // we need to put the vertices into a buffer so we can
    // block transfer them to the graphics hardware
    var trianglePosBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, trianglePosBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, vertexPos, gl.STATIC_DRAW);
    trianglePosBuffer.itemSize = 3;
    trianglePosBuffer.numItems = 24;
    
    // a buffer for normals
    var triangleNormalBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, triangleNormalBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, vertexNormals, gl.STATIC_DRAW);
    triangleNormalBuffer.itemSize = 3;
    triangleNormalBuffer.numItems = 24;
    
    // a buffer for colors
    var colorBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, colorBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, vertexColors, gl.STATIC_DRAW);
    colorBuffer.itemSize = 3;
    colorBuffer.numItems = 24;

// a buffer for textures
    var textureBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, textureBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, vertexTextureCoords, gl.STATIC_DRAW);
    textureBuffer.itemSize = 2;
    textureBuffer.numItems = 24;
	
	var textureBuffer2 = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, textureBuffer2);
    gl.bufferData(gl.ARRAY_BUFFER, vertexTextureCoords2, gl.STATIC_DRAW);
    textureBuffer2.itemSize = 2;
    textureBuffer2.numItems = 24;
	
    // a buffer for indices
    var indexBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, indexBuffer);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, triangleIndices, gl.STATIC_DRAW); 
	
	//more for triangular prism
	var trianglePosBuffer3 = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, trianglePosBuffer3);
    gl.bufferData(gl.ARRAY_BUFFER, vertexPos3, gl.STATIC_DRAW);
    trianglePosBuffer3.itemSize = 3;
    trianglePosBuffer3.numItems = 12;
    
    // a buffer for normals CHECK HERE FOR ERRORS
    var triangleNormalBuffer3 = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, triangleNormalBuffer3);
    gl.bufferData(gl.ARRAY_BUFFER, vertexNormals3, gl.STATIC_DRAW);
    triangleNormalBuffer3.itemSize = 3;
    triangleNormalBuffer3.numItems = 12;
    
    // a buffer for colors
    var colorBuffer3 = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, colorBuffer3);
    gl.bufferData(gl.ARRAY_BUFFER, vertexColors3, gl.STATIC_DRAW);
    colorBuffer3.itemSize = 3;
    colorBuffer3.numItems = 12;

// a buffer for textures
    var textureBuffer3 = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, textureBuffer3);
    gl.bufferData(gl.ARRAY_BUFFER, vertexTextureCoords3, gl.STATIC_DRAW);
    textureBuffer3.itemSize = 2;
    textureBuffer3.numItems = 12;
	
	var indexBuffer3 = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, indexBuffer3);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, triangleIndices3, gl.STATIC_DRAW);
	
	 // Set up texture
    var texture1 = gl.createTexture();
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, texture1);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    var image1 = new Image();
	
	var texture2 = gl.createTexture();
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, texture1);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    var image2 = new Image();
	
	var texture3 = gl.createTexture();
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, texture3);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    var image3 = new Image();
	
    function initTextureThenDraw()
    {
      image1.onload = function() { loadTexture(image1,texture1); };
      image1.crossOrigin = "anonymous";
      image1.src = "https://live.staticflickr.com/65535/52560600204_c13cda29fc_o.jpg";
	  //src="https://live.staticflickr.com/65535/52560600204_c13cda29fc_o.jpg
	  
	  image2.onload = function() { loadTexture(image2,texture2); };
      image2.crossOrigin = "anonymous";
	  image2.width = 1024;
	  image2.height = 1024;
      image2.src = "https://live.staticflickr.com/65535/52559778732_c371ec12d0_o.png";
	  //src="https://live.staticflickr.com/65535/52559778732_c371ec12d0_o.png" width="1024" height="1024"
	  
	  image3.onload = function() { loadTexture(image3,texture3); };
      image3.crossOrigin = "anonymous";
      image3.src = "https://live.staticflickr.com/65535/52560666314_5d768bdaaa_o.jpg";
	  //img src="https://live.staticflickr.com/65535/52560666314_5d768bdaaa_o.jpg" 
	  
      window.setTimeout(draw,200);
    }

    function loadTexture(image,texture)
    {
      gl.bindTexture(gl.TEXTURE_2D, texture);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, image);

      // Option 1 : Use mipmap, select interpolation mode
      gl.generateMipmap(gl.TEXTURE_2D);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);

      // Optional ... if your shader & texture coordinates go outside the [0,1] range
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    }    
	
	function drawCube(Tx1, Tx2, Tx3) {
		gl.uniformMatrix4fv(shaderProgram.MVmatrix,false,Tx1);
        gl.uniformMatrix3fv(shaderProgram.MVNormalmatrix,false,Tx2);
        gl.uniformMatrix4fv(shaderProgram.MVPmatrix,false,Tx3);
                 
        gl.bindBuffer(gl.ARRAY_BUFFER, trianglePosBuffer);
        gl.vertexAttribPointer(shaderProgram.PositionAttribute, trianglePosBuffer.itemSize,
          gl.FLOAT, false, 0, 0);
        gl.bindBuffer(gl.ARRAY_BUFFER, triangleNormalBuffer);
        gl.vertexAttribPointer(shaderProgram.NormalAttribute, triangleNormalBuffer.itemSize,
          gl.FLOAT, false, 0, 0);
        gl.bindBuffer(gl.ARRAY_BUFFER, colorBuffer);
        gl.vertexAttribPointer(shaderProgram.ColorAttribute, colorBuffer.itemSize,
          gl.FLOAT,false, 0, 0);
		  gl.bindBuffer(gl.ARRAY_BUFFER, textureBuffer);
        gl.vertexAttribPointer(shaderProgram.texcoordAttribute, textureBuffer.itemSize,
          gl.FLOAT, false, 0, 0);
		  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, indexBuffer);

        gl.drawElements(gl.TRIANGLES, triangleIndices.length, gl.UNSIGNED_SHORT, 0);
	}
	
	function drawMap(Tx1, Tx2, Tx3) {
		gl.uniformMatrix4fv(shaderProgram2.MVmatrix,false,Tx1);
        gl.uniformMatrix3fv(shaderProgram2.MVNormalmatrix,false,Tx2);
        gl.uniformMatrix4fv(shaderProgram2.MVPmatrix,false,Tx3);
                 
        gl.bindBuffer(gl.ARRAY_BUFFER, trianglePosBuffer);
        gl.vertexAttribPointer(shaderProgram2.PositionAttribute, trianglePosBuffer.itemSize,
          gl.FLOAT, false, 0, 0);
        gl.bindBuffer(gl.ARRAY_BUFFER, triangleNormalBuffer);
        gl.vertexAttribPointer(shaderProgram2.NormalAttribute, triangleNormalBuffer.itemSize,
          gl.FLOAT, false, 0, 0);
        gl.bindBuffer(gl.ARRAY_BUFFER, colorBuffer);
        gl.vertexAttribPointer(shaderProgram2.ColorAttribute, colorBuffer.itemSize,
          gl.FLOAT,false, 0, 0);
		gl.bindBuffer(gl.ARRAY_BUFFER, textureBuffer2);
        gl.vertexAttribPointer(shaderProgram2.texcoordAttribute, textureBuffer2.itemSize,
          gl.FLOAT, false, 0, 0);
		  gl.activeTexture(gl.TEXTURE0);
        gl.bindTexture(gl.TEXTURE_2D, texture2);
		gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, indexBuffer);
		
        gl.drawElements(gl.TRIANGLES, triangleIndices.length, gl.UNSIGNED_SHORT, 0);
	}
	
	function drawCube2(Tx1, Tx2, Tx3) {
		gl.uniformMatrix4fv(shaderProgram3.MVmatrix,false,Tx1);
        gl.uniformMatrix3fv(shaderProgram3.MVNormalmatrix,false,Tx2);
        gl.uniformMatrix4fv(shaderProgram3.MVPmatrix,false,Tx3);
                 
        gl.bindBuffer(gl.ARRAY_BUFFER, trianglePosBuffer);
        gl.vertexAttribPointer(shaderProgram3.PositionAttribute, trianglePosBuffer.itemSize,
          gl.FLOAT, false, 0, 0);
        gl.bindBuffer(gl.ARRAY_BUFFER, triangleNormalBuffer);
        gl.vertexAttribPointer(shaderProgram3.NormalAttribute, triangleNormalBuffer.itemSize,
          gl.FLOAT, false, 0, 0);
        gl.bindBuffer(gl.ARRAY_BUFFER, colorBuffer);
        gl.vertexAttribPointer(shaderProgram3.ColorAttribute, colorBuffer.itemSize,
          gl.FLOAT,false, 0, 0);
		  gl.bindBuffer(gl.ARRAY_BUFFER, textureBuffer);
        gl.vertexAttribPointer(shaderProgram3.texcoordAttribute, textureBuffer.itemSize,
          gl.FLOAT, false, 0, 0);
		  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, indexBuffer);

        gl.drawElements(gl.TRIANGLES, triangleIndices.length, gl.UNSIGNED_SHORT, 0);
	}
	function drawPrism(Tx1, Tx2, Tx3) {
		gl.uniformMatrix4fv(shaderProgram.MVmatrix,false,Tx1);
        gl.uniformMatrix3fv(shaderProgram.MVNormalmatrix,false,Tx2);
        gl.uniformMatrix4fv(shaderProgram.MVPmatrix,false,Tx3);
                 
        gl.bindBuffer(gl.ARRAY_BUFFER, trianglePosBuffer3);
        gl.vertexAttribPointer(shaderProgram3.PositionAttribute, trianglePosBuffer3.itemSize,
          gl.FLOAT, false, 0, 0);
        gl.bindBuffer(gl.ARRAY_BUFFER, triangleNormalBuffer3);
        gl.vertexAttribPointer(shaderProgram3.NormalAttribute, triangleNormalBuffer3.itemSize,
          gl.FLOAT, false, 0, 0);
        gl.bindBuffer(gl.ARRAY_BUFFER, colorBuffer3);
        gl.vertexAttribPointer(shaderProgram3.ColorAttribute, colorBuffer3.itemSize,
          gl.FLOAT,false, 0, 0);
		  gl.bindBuffer(gl.ARRAY_BUFFER, textureBuffer3);
        gl.vertexAttribPointer(shaderProgram3.texcoordAttribute, textureBuffer3.itemSize,
          gl.FLOAT, false, 0, 0);
		gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, indexBuffer3);
		  
        gl.drawElements(gl.TRIANGLES, triangleIndices3.length, gl.UNSIGNED_SHORT, 0);
	}
	
    function draw() {
		gl.useProgram(shaderProgram);
		
		gl.activeTexture(gl.TEXTURE0);
        gl.bindTexture(gl.TEXTURE_2D, texture1);
		
        // Translate slider values to angles in the [-pi,pi] interval
        var angle1 = slider1.value*0.01*Math.PI;
		var trans = slider2.value*1;
    
        
        var eye = [400*Math.sin(angle1),200.0,400.0*Math.cos(angle1)];
        var target = [0,-40,0];
        var up = [0,1,0];
    
        var tModel = mat4.create();
        mat4.fromScaling(tModel,[1,1,1]);
      
        var tCamera = mat4.create();
        mat4.lookAt(tCamera, eye, target, up);      

        var tProjection = mat4.create();
        mat4.perspective(tProjection,Math.PI/4,1,10,1500);
      
        var tMV = mat4.create();
        var tMVn = mat3.create();
        var tMVP = mat4.create();
        mat4.multiply(tMV,tCamera,tModel); // "modelView" matrix
        mat3.normalFromMat4(tMVn,tMV);
        mat4.multiply(tMVP,tProjection,tMV);
      
        // Clear screen, prepare for rendering
        gl.clearColor(0.0, 0.0, 0.0, 1.0);
        gl.enable(gl.DEPTH_TEST);
        gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
	   
	   var Tscale1 = mat4.create();
	   mat4.fromScaling(Tscale1, [40, 40, 60]);
	   mat4.multiply(Tscale1, tMVP, Tscale1);
	   
	   drawCube(tMV, tMVn, Tscale1);
	   
	   //draw one fin
	   var Ttrans1 = mat4.create();
		mat4.translate(Ttrans1, Ttrans1, [60, -10, 20]);
		mat4.multiply(Ttrans1,tMVP,Ttrans1); 
		
	   var Tscale2 = mat4.create();
	   mat4.fromScaling(Tscale2, [20, 10, 10]);
	   mat4.multiply(Tscale2, Ttrans1, Tscale2);
	   
	   var Trot1 = mat4.create();
	   mat4.fromRotation(Trot1, Math.PI/4, [0, -1, 0]);
	   mat4.multiply(Trot1, Tscale2, Trot1);
	   
	   var Trot2 = mat4.create();
	   mat4.fromRotation(Trot2, -(Math.PI/3), [-1, 0, 0]);
	   mat4.multiply(Trot2, Trot1, Trot2);
	   
	   drawCube(tMV, tMVn, Trot2);
	   
	   //repeat for other fin
	   
	   var Ttrans2 = mat4.create();
		mat4.translate(Ttrans2, Ttrans2, [-60, -10, 20]);
		mat4.multiply(Ttrans2,tMVP,Ttrans2); 
		
	   var Tscale3 = mat4.create();
	   mat4.fromScaling(Tscale3, [-20, 10, 10]);
	   mat4.multiply(Tscale3, Ttrans2, Tscale3);
	   
	   var Trot3 = mat4.create();
	   mat4.fromRotation(Trot3, Math.PI/4, [0, -1, 0]);
	   mat4.multiply(Tscale3, Tscale3, Trot3);
	   
	   var Trot4 = mat4.create();
	   mat4.fromRotation(Trot4, -(Math.PI/3), [-1, 0, 0]);
	   mat4.multiply(Tscale3, Tscale3, Trot4);
	   
	   drawCube(tMV, tMVn, Tscale3);
	   
	   //draw tail part
	   
	   var Tscale3 = mat4.create();
	   mat4.fromScaling(Tscale3, [10, 40, 30]);
	   mat4.multiply(Tscale3, tMVP, Tscale3);
	   
	   var Ttrans3 = mat4.create();
		mat4.translate(Ttrans3, Ttrans3, [0, 0, -3]);
		mat4.multiply(Ttrans3, Tscale3, Ttrans3); 
	   
	   var Trot5 = mat4.create();
	   mat4.fromYRotation(Trot5, Math.PI/4);
	   mat4.multiply(Ttrans3, Ttrans3, Trot5);
	   
	   drawCube(tMV, tMVn, Ttrans3);
	   
	   //draw top fin
	   var Tscale4 = mat4.create();
	   mat4.fromScaling(Tscale4, [20, 40, 40]);
	   mat4.multiply(Tscale4, tMVP, Tscale4);
	   
	   var Ttrans4 = mat4.create();
		mat4.translate(Ttrans4, Ttrans4, [0, 1, 0]);
		mat4.multiply(Ttrans4, Tscale4, Ttrans4); 
		
		drawPrism(tMV, tMVn, Ttrans4);
	   
	   gl.useProgram(shaderProgram2);
		
	   var TscaleMap = mat4.create();
	   mat4.fromScaling(TscaleMap, [400, 400, 400]);
	   mat4.multiply(TscaleMap, tMVP, TscaleMap);
	   
	   drawMap(tMV, tMVn, TscaleMap);
	   
	   gl.useProgram(shaderProgram3);
		
		gl.activeTexture(gl.TEXTURE0);
        gl.bindTexture(gl.TEXTURE_2D, texture3);
		
		var TtransWav = mat4.create();
		mat4.translate(TtransWav, TtransWav, [0, (-200 + trans), 0]);
		mat4.multiply(TtransWav,tMVP,TtransWav); 
		
		var TscaleWaves = mat4.create();
	   mat4.fromScaling(TscaleWaves, [400, 10, 400]);
	   mat4.multiply(TscaleWaves, TtransWav, TscaleWaves);
	   
		drawCube2(tMV, tMVn, TscaleWaves);
    }

    slider1.addEventListener("input",draw);
    slider2.addEventListener("input",draw);
    initTextureThenDraw();
}

window.onload=start;